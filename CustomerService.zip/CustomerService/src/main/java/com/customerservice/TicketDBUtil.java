package com.customerservice;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;


public class TicketDBUtil {
    
    private static boolean isSuccess;
    private static Connection con = null;
    private static Statement stmt = null;
    private static ResultSet rs = null;
	//To Insert
	public static boolean insertticket(String subject, String priority, String category, String issue) {
		
		boolean isSuccess = false;
		
		try {
    		    con = DBConnect.getConnection();
                stmt = con.createStatement();
    			
    			String sql = "insert into ticketdb values (0,'"+subject+"','"+priority+"','"+category+"','"+issue+"')";
    			int rs =stmt.executeUpdate(sql);
    			
    			if(rs > 0) {
    				isSuccess = true;
    			}else {
    				isSuccess = false;
			}
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		
		return isSuccess;
		
	}	

	    public static boolean updateTicket(String id, String issue) {
	        
	        try {
                con = DBConnect.getConnection();
                stmt = con.createStatement();
                System.out.print(id);
                String sql = "update ticketdb set issue = '"+issue+"' where ticketID = '"+id+"'";
                int rs =stmt.executeUpdate(sql);
                
                if(rs > 0) {
                    isSuccess = true;
                }else {
                    isSuccess = false;
            }
            
        }
        catch(Exception e) {
            e.printStackTrace();
        }
	        
	        return isSuccess;
	    }
	    
	    public static boolean deleteTicket(String id) {
	        
	           try {
	                con = DBConnect.getConnection();
	                stmt = con.createStatement();
	                System.out.print(id);
	                String sql = "delete from ticketdb where ticketID = '"+id+"'";
	                int rs =stmt.executeUpdate(sql);
	                
	                if(rs > 0) {
	                    isSuccess = true;
	                }else {
	                    isSuccess = false;
	            }
	            
	        }
	        catch(Exception e) {
	            e.printStackTrace();
	        }
	            
	            return isSuccess;
	    }
	
}
